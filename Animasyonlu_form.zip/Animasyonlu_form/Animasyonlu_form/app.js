var telefonAramaInput = document.getElementById("telefonAramaInput");
var adInput = document.getElementById("adInput");
var soyadInput = document.getElementById("soyadInput");
var ePostaInput = document.getElementById("inputEMail");
var sifreInput = document.getElementById("inputSifre");
var dogumTarihiInput = document.getElementById("inputDogumTarihi");
var kadinInput = document.getElementById("inputKadin");
var erkekInput = document.getElementById("inputErkek");
var sehirlerInput = document.getElementById("sehirlerInput");
var cepTelefonuInput = document.getElementById("cepTelefonuInput");
var style1Input = document.getElementById("style1Input");
var style2Input = document.getElementById("style2Input");
var style3Input = document.getElementById("style3Input");
var style4Input = document.getElementById("style4Input");
var sozlesmeInput = document.getElementById("sozlesmeInput");

var cinsiyet = "";


var adlar = [];
var soyadlar = [];
var ePostalar = [];
var sifreler = [];
var dogumTarihleri = [];
var cinsiyetler = [];
var sehirler = [];
var cepTelefonlari = [];

function cinsiyetVer() {
    cinsiyet = "";
    if (kadinInput.checked) {
        cinsiyet = "Kadın";
    }
    else {
        if (erkekInput.checked) {
            cinsiyet = "Erkek";
        }
    }
}

function bosKontrol() {
    cinsiyetVer();
    if (adInput.value == "" || soyadInput.value == "" || ePostaInput.value == "" || sifreInput.value == "" || dogumTarihiInput.value == "" || sehirlerInput.value == "" || cepTelefonuInput.value == "" || sozlesmeInput.checked == false || cinsiyet == "") {
        return false;
    }
    return true;
}


function cepTelefonKontrol() {
    if (cepTelefonlari.indexOf(cepTelefonuInput.value) == -1) {
        return true;
    }
    return false;
}

function temizle() {
    adInput.value = "";
    soyadInput.value = "";
    ePostaInput.value = "";
    sifreInput.value = "";
    dogumTarihiInput.value = "";
    sehirlerInput.value = "";
    cepTelefonuInput.value = "";
    kadinInput.checked = false;
    erkekInput.checked = false;
    sozlesmeInput.checked = false;
    document.getElementById("tabloAd").innerText = "";
    document.getElementById("tabloSoyad").innerText="";
    document.getElementById("tabloEPosta").innerText = "";
    document.getElementById("tabloSifre").innerText = "";
    document.getElementById("tabloDogumTarihi").innerText = "";
    document.getElementById("tabloCinsiyet").innerText = "";
    document.getElementById("tabloSehir").innerText = "";
    document.getElementById("tabloCepTelefonu").innerText = "";

}


function ekle() {
    if (bosKontrol()) {
        if (cepTelefonKontrol()) {
            adlar.push(adInput.value);
            soyadlar.push(soyadInput.value);
            ePostalar.push(ePostaInput.value);
            sifreler.push(sifreInput.value);
            dogumTarihleri.push(dogumTarihiInput.value);
            cinsiyetler.push(cinsiyet);
            sehirler.push(sehirlerInput.value);
            cepTelefonlari.push(cepTelefonuInput.value);
            animationAyarlama("tik1");
            temizle();
        }
        else {
            alert("Bu Cep Telefonu Zaten Ekli!");
        }
    }
    else {
        alert("Lütfen Tüm Alanları Doldurunuz!");
    }
}

function guncelle() {
    if (bosKontrol()) {
        if (cepTelefonKontrol() == false) {
            var index = cepTelefonlari.indexOf(cepTelefonuInput.value);
            adlar[index] = adInput.value;
            soyadlar[index] = soyadInput.value;
            ePostalar[index] = ePostaInput.value;
            sifreler[index] = sifreInput.value;
            dogumTarihleri[index] = dogumTarihiInput.value;
            cinsiyetler[index] = cinsiyet;
            sehirler[index] = sehirlerInput.value;
            cepTelefonlari[index] = cepTelefonuInput.value;
            animationAyarlama("guncelleme");
            temizle();

        }
        else {
            alert("Güncellemek İstediğiniz Kişi Ekli Değil!")
        }
    }
    else {
        alert("Lütfen Tüm Alanları Doldurunuz!")
    }
}

function sil() {
    if (cepTelefonuInput.value == "") {
        alert("Lütfen Silmek İsediğiniz Kişinin Telefon Numarasını 2. Telefon Girişine Giriniz!");
    }
    else {
        if (cepTelefonKontrol() == false) {
            var index = cepTelefonlari.indexOf(cepTelefonuInput.value);
            adlar.splice(index, 1);
            soyadlar.splice(index, 1);
            ePostalar.splice(index, 1);
            sifreler.splice(index, 1);
            dogumTarihleri.splice(index, 1);
            cinsiyetler.splice(index, 1);
            sehirler.splice(index, 1);
            cepTelefonlari.splice(index, 1);
            animationAyarlama("carpi");
            temizle();
        }
        else {
            alert("Silmek İstediğniz Bu Kişi Kayıtlı Değil!");
        }
    }
}
var a;

function animasyonAyarla() {
    var randomSayi = Math.floor(Math.random() * 6);
    document.getElementsByTagName("body")[0].style.backgroundImage = "url(" + "resimler/resim" + randomSayi + ".jpg";
    document.getElementsByTagName("body")[0].style.transition = "2s";
    document.getElementById("form").style.backgroundSize = "contain";
    document.getElementById("form").style.animation = "renkAnimasyonu 5s infinite";
    a = setInterval(resimDegistirmeFonksiyonu, 1000);
}


var resimDegistirmeFonksiyonu = function resimDegisme() {
    var sayi = Math.floor(Math.random() * 6);
    document.getElementsByTagName("body")[0].style.backgroundImage = "url(" + "resimler/resim" + sayi + ".jpg";
}

function arama() {
    if (telefonAramaInput.value == "") {
        alert("Lütfen Aramak İstediğiniz Kişinin Telefon Numarasını Giriniz!");
    }
    else {
        if (cepTelefonlari.indexOf(telefonAramaInput.value) != -1) {
            var index = cepTelefonlari.indexOf(telefonAramaInput.value);
            document.getElementById("tabloAd").innerText = adlar[index];
            document.getElementById("tabloSoyad").innerText = soyadlar[index];
            document.getElementById("tabloEPosta").innerText = ePostalar[index];
            document.getElementById("tabloSifre").innerText = sifreler[index];
            document.getElementById("tabloDogumTarihi").innerText = dogumTarihleri[index];
            document.getElementById("tabloCinsiyet").innerText = cinsiyetler[index];
            document.getElementById("tabloSehir").innerText = sehirler[index];
            document.getElementById("tabloCepTelefonu").innerText = cepTelefonlari[index];
            animationAyarlama("se1");
        }
        else {
            alert("Aramak İstediğiniz Kişi Bulunamadı!");
        }
    }
}


function animationAyarlama(resim) {
    if (document.getElementsByTagName("img")[0].classList.contains("invisible")) {
        document.getElementsByTagName("img")[0].classList.remove("invisible");
    }
    animasyonBaslat();
    document.getElementsByTagName("img")[0].src = "resimler/" + resim + ".png";
    setTimeout(animasyonDurdurma, 3001);

}

var animasyonDurdurma = function animasyonDurdur() {
    document.getElementsByTagName("img")[0].style.animationPlayState = "paused";
}

function animasyonBaslat() {
    document.getElementsByTagName("img")[0].style.animationPlayState = "running";
}

document.getElementById("form").classList.remove();


function styleVerme() {
    if (document.getElementById("style1Input").checked) {
        if (document.getElementById("form").classList.contains("style2")) {
            document.getElementById("form").classList.remove("style2");
            document.getElementById("form").classList.add("style1");
        }
        else if (document.getElementById("form").classList.contains("style3")) {
            document.getElementById("form").classList.remove("style3");
            document.getElementById("form").classList.add("style1");
        }
        else if (document.getElementById("form").classList.contains("style4")) {
            document.getElementById("form").classList.remove("style4");
            document.getElementById("form").classList.add("style1");
        }
    }
    else if (document.getElementById("style2Input").checked) {
        if (document.getElementById("form").classList.contains("style1")) {
            document.getElementById("form").classList.remove("style1");
            document.getElementById("form").classList.add("style2");
        }
        else if (document.getElementById("form").classList.contains("style3")) {
            document.getElementById("form").classList.remove("style3");
            document.getElementById("form").classList.add("style2");
        }
        else if (document.getElementById("form").classList.contains("style4")) {
            document.getElementById("form").classList.remove("style4");
            document.getElementById("form").classList.add("style2");
        }
    }
    else if (document.getElementById("style3Input").checked) {
        if (document.getElementById("form").classList.contains("style1")) {
            document.getElementById("form").classList.remove("style1");
            document.getElementById("form").classList.add("style3");
        }
        else if (document.getElementById("form").classList.contains("style2")) {
            document.getElementById("form").classList.remove("style2");
            document.getElementById("form").classList.add("style3");
        }
        else if (document.getElementById("form").classList.contains("style4")) {
            document.getElementById("form").classList.remove("style4");
            document.getElementById("form").classList.add("style3");
        }
    }
    else if (document.getElementById("style4Input").checked) {
        if (document.getElementById("form").classList.contains("style1")) {
            document.getElementById("form").classList.remove("style1");
            document.getElementById("form").classList.add("style4");
        }
        else if (document.getElementById("form").classList.contains("style2")) {
            document.getElementById("form").classList.remove("style2");
            document.getElementById("form").classList.add("style4");
        }
        else if (document.getElementById("form").classList.contains("style3")) {
            document.getElementById("form").classList.remove("style3");
            document.getElementById("form").classList.add("style4");
        }
    }
}